import React, { useState, useEffect } from 'react';
import { getCart, createCheckout } from './CheckoutService';
import PayPalButton from './PayPalButton';

const CheckoutPage = () => {
  const [cart, setCart] = useState(null);

  useEffect(() => {
    const fetchCart = async () => {
      const cartData = await getCart();
      setCart(cartData);
    };
    fetchCart();
  }, []);

  const handleCheckout = async () => {
    if (cart) {
      const checkout = await createCheckout(cart.id);
      // Redirect to the checkout page or show confirmation
      console.log('Checkout created:', checkout);
    }
  };

  return (
    <div className="checkout-container">
      <h1>Checkout</h1>
      {cart ? (
        <div>
          <h2>Cart Total: ${cart.total}</h2>
          <PayPalButton />
          <button onClick={handleCheckout}>Complete Checkout</button>
        </div>
      ) : (
        <p>Loading cart...</p>
      )}
    </div>
  );
};

export default CheckoutPage;
