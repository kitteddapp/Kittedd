import { CheckoutAPI } from '@bigcommerce/checkout-sdk';

const checkoutAPI = new CheckoutAPI();

export const getCart = async () => {
  try {
    const cart = await checkoutAPI.getCart();
    return cart;
  } catch (error) {
    console.error("Error fetching cart: ", error);
  }
};

export const createCheckout = async (cartId) => {
  try {
    const checkout = await checkoutAPI.createCheckout({ cartId });
    return checkout;
  } catch (error) {
    console.error("Error creating checkout: ", error);
  }
};
