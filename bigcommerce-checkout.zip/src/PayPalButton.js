import React, { useEffect } from 'react';

const PayPalButton = () => {
  useEffect(() => {
    if (window.paypal) {
      window.paypal.Buttons({
        createOrder(data, actions) {
          return actions.order.create({
            purchase_units: [{
              amount: {
                value: '100.00'  // Use dynamic cart value
              }
            }]
          });
        },
        onApprove(data, actions) {
          return actions.order.capture().then(function(details) {
            console.log('Payment successful:', details);
          });
        }
      }).render('#paypal-button-container');
    }
  }, []);

  return (
    <div id="paypal-button-container"></div>
  );
};

export default PayPalButton;
