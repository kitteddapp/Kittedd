import React from 'react';
import CheckoutPage from './CheckoutPage';

function App() {
  return (
    <div className="App">
      <CheckoutPage />
    </div>
  );
}

export default App;
